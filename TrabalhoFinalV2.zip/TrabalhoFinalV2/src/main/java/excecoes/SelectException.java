package excecoes;

public class SelectException extends Exception{
    public SelectException(String mensagem) {
        super(mensagem);
    }
}